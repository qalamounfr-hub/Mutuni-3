// Alignement approximatif au niveau mot, basé sur une distance d'édition de
// Levenshtein caractère par caractère entre chaque paire de mots. Sert à la
// fois à détecter le chevauchement entre deux fenêtres CTC successives (qui
// peuvent segmenter le même son différemment, ex. "الرحيمم" vs "رحيمما") et à
// comparer un transcript à un bayt attendu sans casser au premier désaccord.

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const al = a.length, bl = b.length;
  if (al === 0) return bl;
  if (bl === 0) return al;
  const prev = new Array(bl + 1);
  const curr = new Array(bl + 1);
  for (let j = 0; j <= bl; j += 1) prev[j] = j;
  for (let i = 1; i <= al; i += 1) {
    curr[0] = i;
    for (let j = 1; j <= bl; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= bl; j += 1) prev[j] = curr[j];
  }
  return prev[bl];
}

// Deux mots sont considérés "identiques" pour l'alignement si leur distance
// d'édition relative reste faible (tolère les petites variantes de
// segmentation/orthographe du décodeur CTC glouton sans confondre deux mots
// réellement différents).
export function wordsMatch(a: string, b: string): boolean {
  if (a === b) return true;
  if (!a || !b) return false;
  const dist = levenshtein(a, b);
  const maxLen = Math.max(a.length, b.length);
  return dist <= Math.max(1, Math.floor(maxLen * 0.34));
}

// Alignement global tolérant (programmation dynamique, type diff) entre le
// transcript obtenu et le texte attendu, au lieu d'un simple glissement
// séquentiel qui se désynchronise dès le premier désaccord. Retourne le
// nombre de mots du texte attendu retrouvés (dans l'ordre, insertions et
// omissions autorisées) et le total de mots attendus.
export function alignedMatchCount(expectedWords: string[], actualWords: string[]): {matches: number; total: number} {
  const n = expectedWords.length, m = actualWords.length;
  if (n === 0) return {matches: 0, total: 0};
  if (m === 0) return {matches: 0, total: n};
  // dp[i][j] = plus grand nombre de correspondances entre expected[0..i) et actual[0..j)
  let prev = new Array(m + 1).fill(0);
  let curr = new Array(m + 1).fill(0);
  for (let i = 1; i <= n; i += 1) {
    curr[0] = 0;
    for (let j = 1; j <= m; j += 1) {
      const matchHere = wordsMatch(expectedWords[i - 1], actualWords[j - 1]) ? prev[j - 1] + 1 : -Infinity;
      curr[j] = Math.max(matchHere, prev[j], curr[j - 1]);
    }
    [prev, curr] = [curr, prev];
  }
  return {matches: prev[m], total: n};
}

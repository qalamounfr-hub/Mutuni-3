export const VERSION = '5.0.0';
export const CACHE_NAMESPACE = `mutuni-model-v5`;

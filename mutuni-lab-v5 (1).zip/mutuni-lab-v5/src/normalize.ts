const DIACRITICS = /[\u064B-\u0652\u0670\u0640]/g;
export function normalizeArabic(input = ''): string {
  let s = String(input).normalize('NFKC').replace(DIACRITICS, '')
    .replace(/[آأإٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه')
    .replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ء/g, '')
    .replace(/[،؛؟,:.!؟\-–—()[\]{}«»]/g, ' ')
    .replace(/[\u0660-\u0669]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/\s+/g, ' ').trim();
  return s.replace(/(.)\1+/g, '$1');
}
export function tokenizeExpected(text: string): string[] { return normalizeArabic(text).split(/\s+/).filter(Boolean); }
export function boundedLevenshtein(a: string, b: string, bound = Math.max(a.length, b.length)): number {
  if (Math.abs(a.length-b.length)>bound) return bound+1;
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=1;i<=a.length;i++) { const cur=[i]; let rowMin=cur[0]; for(let j=1;j<=b.length;j++){ const v=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1)); cur[j]=v; rowMin=Math.min(rowMin,v); } if(rowMin>bound)return bound+1; prev=cur; }
  return prev[b.length];
}
export function similarity(a: string, b: string): number { const x=normalizeArabic(a), y=normalizeArabic(b), m=Math.max(x.length,y.length); return m?Math.max(0,1-boundedLevenshtein(x,y,m)/m):1; }

import {normalizeArabic, tokenizeExpected, similarity} from './normalize';
export type WordStatus = 'pending'|'matched'|'skipped'|'uncertain';
export interface CursorWord { expected:string; heard:string|null; score:number; status:WordStatus; index:number; }
export class Cursor {
 static readonly ACCEPT=0.72; static readonly UNCERTAIN=0.55; static readonly LOOKAHEAD=3; static readonly SKIP_PENALTY=0.08;
 private expected:string[]=[]; private words:CursorWord[]=[]; private consumed=0;
 constructor(expected: string|string[] = []) { this.setExpected(expected); }
 setExpected(expected:string|string[]) { this.expected=Array.isArray(expected)?expected.map(normalizeArabic).filter(Boolean):tokenizeExpected(expected); this.reset(); }
 reset(){this.consumed=0; this.words=this.expected.map((expected,index)=>({expected,heard:null,score:0,status:'pending',index}));}
 advance(heardWords:string[]): CursorWord[] { const fresh=heardWords.slice(this.consumed); this.consumed=heardWords.length; for(const heardRaw of fresh){const heard=normalizeArabic(heardRaw); if(!heard)continue; if(this.consumed<0)continue; let best=-1,bestScore=0,bestEffective=0; const next=this.nextIndex(); for(let i=next;i<Math.min(this.expected.length,next+Cursor.LOOKAHEAD+1);i++){const s=similarity(this.expected[i],heard), effective=s-Cursor.SKIP_PENALTY*(i-next); if(effective>bestEffective){bestScore=s;bestEffective=effective;best=i;}} if(best<0)continue; if(best>next && best-next<=Cursor.LOOKAHEAD && bestEffective>=Cursor.ACCEPT){ for(let i=next;i<best;i++)this.words[i].status='skipped'; } if(bestScore>=Cursor.ACCEPT){this.words[best]={...this.words[best],heard,score:bestScore,status:'matched'};} else if(bestScore>=Cursor.UNCERTAIN && this.words[best].status==='pending'){this.words[best]={...this.words[best],heard,score:bestScore,status:'uncertain'};} }
 return this.snapshot(); }
 private nextIndex(){let i=0; while(i<this.words.length&&this.words[i].status==='matched')i++; while(i<this.words.length&&this.words[i].status==='skipped')i++; return i;}
 snapshot(){return this.words.map(w=>({...w}));}
 report(){const c={pending:0,matched:0,skipped:0,uncertain:0}; for(const w of this.words)c[w.status]++; const total=this.words.length; return {...c,total,position:this.nextIndex(),score:total?Math.round((c.matched+c.uncertain*.5)/total*100):0};}
}

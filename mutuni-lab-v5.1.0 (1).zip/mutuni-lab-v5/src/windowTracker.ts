import {normalizeArabic} from './normalize';

export interface WindowPacket { sessionId:number; windowId:number; audioStart:number; audioEnd:number; text:string; final?:boolean; }
export interface TrackerState { words:string[]; confirmedWords:string[]; provisionalWords:string[]; acceptedWindows:number; rejectedLate:number; rejectedDuplicate:number; lastAudioStart:number; }

/** Deterministic temporal fusion. Window identity and audio bounds are authoritative;
 * text overlap is only used to fuse words, never to advance time. */
export class TemporalTracker {
  private state:TrackerState = {words:[], confirmedWords:[], provisionalWords:[], acceptedWindows:0,rejectedLate:0,rejectedDuplicate:0,lastAudioStart:-1};
  private seen = new Set<string>();
  reset(){ this.state={words:[],confirmedWords:[],provisionalWords:[],acceptedWindows:0,rejectedLate:0,rejectedDuplicate:0,lastAudioStart:-1}; this.seen.clear(); }
  ingest(p:WindowPacket): TrackerState {
    const key=`${p.sessionId}:${p.windowId}`;
    if(this.seen.has(key)){this.state.rejectedDuplicate++; return this.snapshot();}
    this.seen.add(key);
    if(p.audioStart < this.state.lastAudioStart){this.state.rejectedLate++; return this.snapshot();}
    this.state.lastAudioStart=p.audioStart; this.state.acceptedWindows++;
    const incoming=normalizeArabic(p.text).split(/\s+/).filter(Boolean);
    if(incoming.length) this.state.words=this.merge(this.state.words,incoming);
    // A word seen in two consecutive temporal windows is confirmed. Final windows confirm all.
    const prior=this.state.provisionalWords;
    this.state.confirmedWords=p.final ? this.state.words.slice() : this.state.words.filter((w,i)=>prior.includes(w) || i < Math.max(0,this.state.words.length-incoming.length));
    this.state.provisionalWords=this.state.words.filter(w=>!this.state.confirmedWords.includes(w));
    return this.snapshot();
  }
  private merge(oldWords:string[], incoming:string[]):string[]{
    const max=Math.min(oldWords.length,incoming.length,12); let overlap=0;
    for(let k=max;k>0;k--){let ok=true; for(let i=0;i<k;i++) if(oldWords[oldWords.length-k+i]!==incoming[i]) {ok=false;break;} if(ok){overlap=k;break;}}
    return oldWords.concat(incoming.slice(overlap));
  }
  snapshot(){return {...this.state,words:this.state.words.slice(),confirmedWords:this.state.confirmedWords.slice(),provisionalWords:this.state.provisionalWords.slice()};}
}

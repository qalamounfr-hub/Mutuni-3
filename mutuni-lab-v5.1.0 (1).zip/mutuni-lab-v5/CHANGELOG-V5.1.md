# v5.1.0 — suivi temporel conservateur

- Ajout de `TemporalTracker`: identifiants de fenêtre et bornes audio monotones, rejet des résultats tardifs/dupliqués, fusion de chevauchement déterministe.
- Les fenêtres exposent `windowId`, `audioStart`, `audioEnd` et `final`; les mots récemment observés restent provisoires jusqu'à confirmation par recouvrement ou fenêtre finale.
- UI: transcript confirmé et provisoire distingués; diagnostics de fenêtres rejetées visibles dans le journal.
- Cache versionné `mutuni-model-v5-1`; modèle, vocabulaire et assets lourds inchangés.
- Pas d'encodeur CTC supplémentaire inventé: la préparation à l'alignement contraint reste limitée aux bornes temporelles et au décodage existant.

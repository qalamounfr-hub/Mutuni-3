import fs from 'node:fs';
const s=fs.readFileSync(new URL('../src/windowTracker.ts',import.meta.url),'utf8');
for (const x of ['windowId','audioStart','rejectedLate','rejectedDuplicate']) if(!s.includes(x)) throw new Error(`missing ${x}`);
console.log('tracker source smoke test: PASS');
